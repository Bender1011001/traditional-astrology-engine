"""
Geomancy package

This package contains a minimal, composable geomancy engine.  The core
module implements the mechanical rules used to generate a geomantic
shield chart from four primary figures (the mothers).  Individual
traditions are implemented in the ``geomancy.traditions`` package as
separate modules.  Each tradition module defines dictionaries or
functions that describe the symbolic meanings of the figures, houses
and higher‑order judgement rules within that specific historical
context.  Keeping the traditions separated allows you to explore
differences between sources without inadvertently merging them into a
single ahistorical system.

Modules
-------

``core``
    Base classes and functions for generating geomantic charts.

``traditions``
    Namespace package containing tradition–specific rule sets.  See
    ``geomancy/traditions/__init__.py`` for an overview.

Example usage
-------------

To generate a random geomantic shield chart and look up the figure
meanings for one of the supplied traditions::

    from geomancy.core import Chart, random_figure, random_mothers
    from geomancy.traditions import agrippa

    # generate four random mother figures and build the chart
    mothers = random_mothers()
    chart = Chart.from_mothers(mothers)

    # examine the judge figure and the figure in the seventh house
    print("Judge figure:", chart.judge)
    print("Figure in the 7th house:", chart.houses[6])

    # look up their meanings according to Agrippa's tradition
    print("Judge meaning:", agrippa.figure_meanings.get(chart.judge.name))
    print("7th house meaning:", agrippa.house_meanings.get(7))

This module intentionally contains no high‑level interpretive logic
because interpretations vary markedly across traditions.  See the
docstrings in the tradition modules for details on how to supply your
own rule sets.
"""

from . import core  # noqa: F401  (re‑export core so consumers can import geomancy.core)
from . import traditions  # noqa: F401  (re‑export traditions)