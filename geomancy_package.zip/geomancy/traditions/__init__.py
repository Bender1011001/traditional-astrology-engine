"""
Tradition‑specific rule sets for geomancy.

This package contains separate modules, one per historical
tradition or major source.  Each module should define a consistent
interface so that the core engine can be combined with any
interpretive system.  A typical tradition module will provide some
or all of the following attributes:

``figure_meanings`` : Dict[str, str]
    A mapping from figure names to descriptive meanings within the
    tradition.

``house_meanings`` : Dict[int, str]
    A mapping from house numbers (1–12) to their meanings within the
    tradition.

``interpret(chart: Chart) -> Dict[str, Any]``
    A function that takes a ``geomancy.core.Chart`` instance and
    returns an interpretation object (possibly another mapping or
    custom class) describing the overall reading according to the
    tradition.

Individual modules may expose additional data structures, such as
planetary rulerships, elemental attributions or advanced rules for
techniques like ``via puncti``, ``perfection`` or ``occupation``.

Example
-------

>>> from geomancy.core import Chart, random_mothers
>>> from geomancy.traditions import agrippa
>>> chart = Chart.from_mothers(random_mothers())
>>> print(agrippa.figure_meanings.get(chart.mothers[0].name))
>>> result = agrippa.interpret(chart)

Note that most of the tradition modules included in this package are
skeletons.  They define the structure and key names but leave
interpretations to be filled in by the user or by importing data
extracted from historical sources.  This separation enables
controlled comparison of different rule sets.
"""

# Re‑export tradition modules at the package level for convenience
from . import agrippa  # noqa: F401
from . import cattan  # noqa: F401
from . import estimaverunt  # noqa: F401
from . import martin  # noqa: F401
from . import zanati  # noqa: F401