"""
Christopher Cattan's tradition (``La Géomance``) circa 1558–1591.

This module defines placeholder data structures for the meanings of
figures and houses as presented in Christopher Cattan's French
geomancy manual (and later English translations).  The real
meanings are far more detailed and often include long lists of
questions and examples; here we provide only indicative phrases.

Users are encouraged to replace the contents of ``figure_meanings``
and ``house_meanings`` with accurate translations from primary
sources.
"""

from __future__ import annotations

from typing import Dict, Any

from ..core import Chart


# Placeholder meanings for Cattan.  Replace with full text.
figure_meanings: Dict[str, str] = {
    "Via": "A way, change of residence, movement",
    "Populus": "A multitude, gathering, neutrality",
    "Fortuna Major": "Great wealth, honour, stability",
    "Fortuna Minor": "Lesser gain, fleeting support",
    "Conjunctio": "Meetings, assemblies, coming together",
    "Carcer": "Boundaries, imprisonment, restrictions",
    "Tristitia": "Sadness, loss, melancholy",
    "Laetitia": "Joy, satisfaction, festivity",
    "Albus": "Peace, wisdom, modesty",
    "Rubeus": "Violence, intoxication, danger",
    "Puella": "Women, charm, attraction, softness",
    "Puer": "Men, conflict, strength",
    "Caput Draconis": "Beginnings, opportunities, growth",
    "Cauda Draconis": "Conclusions, reversals, decline",
    "Acquisitio": "Gain, earnings, advantage",
    "Amissio": "Loss, expense, misfortune",
}

house_meanings: Dict[int, str] = {
    1: "The querent, appearance, mind and body",
    2: "Livelihood, goods, profits, movable possessions",
    3: "Kindred, servants, small travels",
    4: "Heritage, dwellings, hidden things",
    5: "Children, delights, risks, arts",
    6: "Servants, diseases, obligations",
    7: "Spouse, partnerships, open adversaries",
    8: "Deaths, dowries, legacies, fear",
    9: "Long voyages, religion, judiciary matters",
    10: "Honours, office, dignity, commerce",
    11: "Friends, alliances, hopes",
    12: "Enemies, exile, hidden dangers",
}


def interpret(chart: Chart) -> Dict[str, Any]:
    """Interpret a geomantic chart according to Cattan's system.

    Returns a dictionary mapping house numbers to the figure name and
    its meaning.  The witnesses and judge are also included.
    """
    result: Dict[str, Any] = {}
    house_interps = {}
    for house_num, figure in chart.houses.items():
        name = figure.name or f"{figure.bits}"
        fig_mean = figure_meanings.get(name, "Unknown meaning")
        house_mean = house_meanings.get(house_num, "Unknown house")
        house_interps[house_num] = (name, fig_mean, house_mean)
    result["houses"] = house_interps
    # Witnesses and judge
    witness1, witness2 = chart.witnesses
    judge = chart.judge
    result["witnesses"] = (
        (witness1.name or str(witness1.bits), figure_meanings.get(witness1.name or str(witness1.bits), "Unknown")),
        (witness2.name or str(witness2.bits), figure_meanings.get(witness2.name or str(witness2.bits), "Unknown")),
    )
    result["judge"] = (judge.name or str(judge.bits), figure_meanings.get(judge.name or str(judge.bits), "Unknown"))
    return result