"""
al‑Zanati's tradition (``al‑Faṣl fī uṣūl ʿilm al‑raml``).

This module provides placeholder structures to represent the
associations and interpretations attributed to the Arabic master
Abū ʿAbd Allāh al‑Zanātī in his treatise on geomancy.  It is
important to note that extant manuscripts vary and the meanings here
are generic; they should be replaced with actual translations from
the specific recension you are using.
"""

from __future__ import annotations

from typing import Dict, Any

from ..core import Chart


figure_meanings: Dict[str, str] = {
    "Via": "Way, journey, travelling, mobility",
    "Populus": "Community, receptivity, passivity",
    "Fortuna Major": "Great fortune, long‑lasting success",
    "Fortuna Minor": "Small fortune, fleeting aid",
    "Conjunctio": "Union, meetings, agreements",
    "Carcer": "Restrained, enclosed, limitations",
    "Tristitia": "Sadness, decline, loss",
    "Laetitia": "Happiness, elevation, recovery",
    "Albus": "Purity, sincerity, beneficial counsel",
    "Rubeus": "Danger, dispute, temptation",
    "Puella": "Female, gentleness, attraction",
    "Puer": "Male, action, impatience",
    "Caput Draconis": "Beginning, rising, good omen",
    "Cauda Draconis": "End, falling, ill omen",
    "Acquisitio": "Gain, acquisition, profit",
    "Amissio": "Loss, waste, relinquishment",
}

house_meanings: Dict[int, str] = {
    1: "Self, body, spirit, appearance",
    2: "Wealth, food, livelihood",
    3: "Brothers, sisters, neighbors, letters",
    4: "Home, ancestry, hidden matters",
    5: "Children, joy, gambling, arts",
    6: "Illness, servitude, animals, toil",
    7: "Partners, opponents, marriage",
    8: "Death, fear, legacies, taxes",
    9: "Journeys, religion, sciences",
    10: "Authority, profession, kings, office",
    11: "Friends, hopes, benefactors",
    12: "Secrets, enemies, bondage, sorrow",
}


def interpret(chart: Chart) -> Dict[str, Any]:
    """Provide a simple interpretation of the chart according to
    al‑Zanati's tradition.

    Returns a dictionary mapping each house to the figure name,
    placeholder figure meaning and house meaning, as well as
    summarising the witness and judge figures.
    """
    result: Dict[str, Any] = {}
    house_interps = {}
    for house_num, figure in chart.houses.items():
        name = figure.name or f"{figure.bits}"
        fig_mean = figure_meanings.get(name, "Unknown meaning")
        house_mean = house_meanings.get(house_num, "Unknown house")
        house_interps[house_num] = (name, fig_mean, house_mean)
    result["houses"] = house_interps
    witness1, witness2 = chart.witnesses
    judge = chart.judge
    result["witnesses"] = (
        (witness1.name or str(witness1.bits), figure_meanings.get(witness1.name or str(witness1.bits), "Unknown")),
        (witness2.name or str(witness2.bits), figure_meanings.get(witness2.name or str(witness2.bits), "Unknown")),
    )
    result["judge"] = (judge.name or str(judge.bits), figure_meanings.get(judge.name or str(judge.bits), "Unknown"))
    return result