"""
Henricus Cornelius Agrippa's geomancy tradition (16th century).

This module contains placeholder data structures representing the
symbolic meanings of the sixteen geomantic figures and the twelve
houses as outlined in the fourth book of Agrippa's ``De occulta
philosophia``.  These should be replaced with full text from
authoritative sources if you intend to use them for actual
divinatory practice.  The current values are minimal and serve to
illustrate how the structure may be populated.
"""

from __future__ import annotations

from typing import Dict, Any

from ..core import Chart


# Placeholder figure meanings for Agrippa's system.  These short
# descriptions should be replaced with fuller explanations from
# authoritative translations or manuscripts.
figure_meanings: Dict[str, str] = {
    "Via": "Road, journey, movement, instability",
    "Populus": "People, crowds, receptivity, passivity",
    "Fortuna Major": "Great fortune, success, established power",
    "Fortuna Minor": "Lesser fortune, passing success, resourcefulness",
    "Conjunctio": "Union, coming together, agreements",
    "Carcer": "Prison, confinement, obstacles, delays",
    "Tristitia": "Sorrow, downfall, heaviness, pessimism",
    "Laetitia": "Joy, celebration, happiness, optimism",
    "Albus": "White, purity, clarity, peace",
    "Rubeus": "Red, passion, anger, danger",
    "Puella": "Maiden, beauty, attraction, gentleness",
    "Puer": "Youth, courage, conflict, aggression",
    "Caput Draconis": "Head of the dragon, beginnings, destiny, ascent",
    "Cauda Draconis": "Tail of the dragon, endings, fate, descent",
    "Acquisitio": "Gain, profit, increase, advantage",
    "Amissio": "Loss, setback, decrease, disadvantage",
}


# Placeholder house meanings according to typical Renaissance sources.
house_meanings: Dict[int, str] = {
    1: "Self, body, spirit, the querent",
    2: "Wealth, possessions, resources",
    3: "Siblings, communication, short journeys",
    4: "Parents, home, land, foundations",
    5: "Children, creativity, pleasure, speculation",
    6: "Servants, health, illness, small animals",
    7: "Partnerships, marriage, open enemies",
    8: "Death, inheritance, transformation",
    9: "Journeys abroad, religion, higher learning",
    10: "Career, status, honours, the father",
    11: "Friends, hopes, benefactors, wishes",
    12: "Hidden enemies, sorrows, confinement, secrets",
}


def interpret(chart: Chart) -> Dict[str, Any]:
    """Interpret a geomantic chart according to Agrippa's system.

    The current implementation produces a simple dictionary mapping
    each house to a tuple of (figure name, meaning).  It also
    includes the names of the witnesses and the judge.  More
    sophisticated techniques (such as perfection, translation or
    occupation) are not implemented here.

    Parameters
    ----------
    chart : Chart
        A geomantic chart produced by ``geomancy.core.Chart``.

    Returns
    -------
    Dict[str, Any]
        A dictionary containing interpreted information.  Keys include
        ``houses``, ``witnesses`` and ``judge``.
    """
    result: Dict[str, Any] = {}
    # Interpret the houses
    house_interps = {}
    for house_num, figure in chart.houses.items():
        name = figure.name or f"{figure.bits}"
        meaning = figure_meanings.get(name, "Unknown meaning")
        house_meaning = house_meanings.get(house_num, "Unknown house")
        house_interps[house_num] = (name, meaning, house_meaning)
    result["houses"] = house_interps
    # Witnesses and judge
    witness1, witness2 = chart.witnesses
    judge = chart.judge
    result["witnesses"] = (
        (witness1.name or str(witness1.bits), figure_meanings.get(witness1.name or str(witness1.bits), "Unknown")),
        (witness2.name or str(witness2.bits), figure_meanings.get(witness2.name or str(witness2.bits), "Unknown")),
    )
    result["judge"] = (judge.name or str(judge.bits), figure_meanings.get(judge.name or str(judge.bits), "Unknown"))
    return result