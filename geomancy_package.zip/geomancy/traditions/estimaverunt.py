"""
Estimaverunt Indi tradition (anonymous early Latin treatise).

This module provides placeholder structures to hold the meanings
associated with figures and houses as found in the early Latin text
known as ``Estimaverunt Indi`` or ``Existimaverunt Indi``.  It
offers a simple interpretation function that returns the figure
names, their placeholder meanings and the corresponding house
descriptions.

Because the actual content of the treatise is fragmentary and
differs across manuscripts, these values are only indicative and
should be replaced with authoritative translations when available.
"""

from __future__ import annotations

from typing import Dict, Any

from ..core import Chart


figure_meanings: Dict[str, str] = {
    "Via": "Paths, motion, change, journeys",
    "Populus": "Gathering, multitude, agreement",
    "Fortuna Major": "Enduring success, stability",
    "Fortuna Minor": "Transient luck, small profit",
    "Conjunctio": "Connection, union, trade",
    "Carcer": "Bondage, slow progress, hindrance",
    "Tristitia": "Sorrow, loss, misfortune",
    "Laetitia": "Joy, increase, blessing",
    "Albus": "Purity, insight, virtue",
    "Rubeus": "Danger, deceit, desire",
    "Puella": "Women, beauty, charm, union",
    "Puer": "Men, conflict, activity",
    "Caput Draconis": "Beginnings, intention, fortune",
    "Cauda Draconis": "Endings, misfortune, downfall",
    "Acquisitio": "Acquisition, income, benefit",
    "Amissio": "Loss, poverty, absence",
}

house_meanings: Dict[int, str] = {
    1: "Life, physical body, temperament",
    2: "Finances, movables, treasure",
    3: "Neighbors, messages, siblings",
    4: "House, lands, hidden things",
    5: "Children, love affairs, arts",
    6: "Illness, health, work, servants",
    7: "Partners, opponents, contracts",
    8: "Death, inheritances, dowries",
    9: "Faith, travel, sciences",
    10: "Authority, profession, reputation",
    11: "Allies, benefactors, hope",
    12: "Isolation, secrets, self‑undoing",
}


def interpret(chart: Chart) -> Dict[str, Any]:
    """Provide a basic interpretation of the chart according to
    Estimaverunt Indi.

    Returns a mapping of each house to the figure name and its
    placeholder meaning along with the house meaning.  Also includes
    witnesses and judge information.
    """
    result: Dict[str, Any] = {}
    house_interps = {}
    for house_num, figure in chart.houses.items():
        name = figure.name or f"{figure.bits}"
        fig_mean = figure_meanings.get(name, "Unknown meaning")
        house_mean = house_meanings.get(house_num, "Unknown house")
        house_interps[house_num] = (name, fig_mean, house_mean)
    result["houses"] = house_interps
    # Witnesses and judge
    witness1, witness2 = chart.witnesses
    judge = chart.judge
    result["witnesses"] = (
        (witness1.name or str(witness1.bits), figure_meanings.get(witness1.name or str(witness1.bits), "Unknown")),
        (witness2.name or str(witness2.bits), figure_meanings.get(witness2.name or str(witness2.bits), "Unknown")),
    )
    result["judge"] = (judge.name or str(judge.bits), figure_meanings.get(judge.name or str(judge.bits), "Unknown"))
    return result