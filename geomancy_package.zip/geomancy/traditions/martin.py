"""
Martin of Spain's tradition (``De geomancia``) – Middle English translation.

This module contains placeholder structures for the figure and house
meanings found in the Latin treatise commonly attributed to Martin
of Spain and its Middle English translation.  The actual text
provides extensive correspondences such as element, planet, sign and
season for each figure.  The values here are minimal and intended
only to illustrate the API.
"""

from __future__ import annotations

from typing import Dict, Any

from ..core import Chart


figure_meanings: Dict[str, str] = {
    "Via": "Travel, change, routes",
    "Populus": "Masses, neutrality, passivity",
    "Fortuna Major": "High fortune, permanence, nobility",
    "Fortuna Minor": "Modest fortune, transience, assistance",
    "Conjunctio": "Meetings, gatherings, blending",
    "Carcer": "Confinement, stability, security",
    "Tristitia": "Falling, sorrow, separation",
    "Laetitia": "Rising, joy, delight",
    "Albus": "White, clarity, wisdom",
    "Rubeus": "Red, passion, danger",
    "Puella": "Girl, pleasure, adornment",
    "Puer": "Boy, boldness, conflict",
    "Caput Draconis": "Head, beginning, prosperity",
    "Cauda Draconis": "Tail, ending, decline",
    "Acquisitio": "Gain, increase, acquisition",
    "Amissio": "Loss, decrease, letting go",
}

house_meanings: Dict[int, str] = {
    1: "Person, life, complexion",
    2: "Riches, living, moveable goods",
    3: "Brethren, neighbors, letters",
    4: "Fathers, dwellings, lands",
    5: "Children, delights, gambling",
    6: "Infirmities, servants, beasts",
    7: "Marriage, partnerships, lawsuits",
    8: "Death, dowries, legacies",
    9: "Religion, learning, pilgrimages",
    10: "Estate, reputation, magistracy",
    11: "Friendship, gifts, praise",
    12: "Enemies, bondage, imprisonment",
}


def interpret(chart: Chart) -> Dict[str, Any]:
    """Provide a basic interpretation of a geomantic chart according
    to Martin of Spain.

    Returns a dictionary mapping houses to tuples of figure name,
    figure meaning and house meaning, along with witness and judge
    names and placeholder meanings.
    """
    result: Dict[str, Any] = {}
    house_interps = {}
    for house_num, figure in chart.houses.items():
        name = figure.name or f"{figure.bits}"
        fig_mean = figure_meanings.get(name, "Unknown meaning")
        house_mean = house_meanings.get(house_num, "Unknown house")
        house_interps[house_num] = (name, fig_mean, house_mean)
    result["houses"] = house_interps
    witness1, witness2 = chart.witnesses
    judge = chart.judge
    result["witnesses"] = (
        (witness1.name or str(witness1.bits), figure_meanings.get(witness1.name or str(witness1.bits), "Unknown")),
        (witness2.name or str(witness2.bits), figure_meanings.get(witness2.name or str(witness2.bits), "Unknown")),
    )
    result["judge"] = (judge.name or str(judge.bits), figure_meanings.get(judge.name or str(judge.bits), "Unknown"))
    return result