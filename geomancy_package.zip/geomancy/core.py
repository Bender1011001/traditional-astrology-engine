"""
Core geomancy engine.

This module defines classes and functions to represent geomantic
figures and to build a geomantic shield chart from four primary
figures (the mothers).  It implements the mechanical rules of
combination using binary parity (logical XOR) to derive daughters,
nieces, witnesses and the judge.  No interpretive meaning is
attached in this module; users should consult the tradition modules
for symbolic associations.

Geomantic Figures
-----------------

Each geomantic figure is represented by four boolean values (bits)
corresponding to the "fire" (head), "air" (neck), "water" (belly)
and "earth" (feet) lines.  A value of ``True`` denotes an odd
number of dots (a single dot) and a value of ``False`` denotes an
even number of dots (a pair of dots) in the traditional way of
generating figures.

The standard list of sixteen figure names is provided for
reference, but the core engine does not enforce any particular
ordering or naming.  Traditions may assign different names or
meanings to identical binary patterns.

Usage
-----

>>> from geomancy.core import Figure, Chart, random_figure, random_mothers
>>> # generate four random mothers
>>> mothers = random_mothers()
>>> chart = Chart.from_mothers(mothers)
>>> # inspect the judge and witnesses
>>> print(chart.judge, chart.witnesses)
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import List, Tuple, Dict, Sequence


@dataclass(frozen=True)
class Figure:
    """A geomantic figure represented by four boolean values.

    Each figure comprises four lines from head (fire) to feet (earth).
    A value of ``True`` indicates an odd line (•) and ``False``
    indicates an even line (••).  Figures are immutable and hashable
    so they can be used as dictionary keys.

    Parameters
    ----------
    name : str
        Optional descriptive name for the figure.  Not used by the
        engine logic, but provided for easier debugging and display.
    bits : Sequence[bool]
        A sequence of four boolean values representing the lines from
        head to feet.  The sequence is stored as a tuple internally.
    """

    name: str
    bits: Tuple[bool, bool, bool, bool]

    def __post_init__(self) -> None:
        if len(self.bits) != 4:
            raise ValueError("A figure must have exactly 4 lines")

    def combine(self, other: "Figure") -> "Figure":
        """Combine two figures using binary parity (XOR).

        The resulting figure has bits where each line is ``True`` if
        exactly one of the corresponding input bits is ``True`` (odd),
        and ``False`` if both are equal (even).  The name of the
        resulting figure is not set; call ``Figure`` with a name if
        desired.

        Parameters
        ----------
        other : Figure
            The second figure to combine with this figure.

        Returns
        -------
        Figure
            A new figure representing the bitwise XOR of the two
            figures.
        """
        if not isinstance(other, Figure):
            raise TypeError("Can only combine with another Figure")
        bits = tuple(a ^ b for a, b in zip(self.bits, other.bits))
        return Figure(name="", bits=bits)

    @staticmethod
    def from_bits(bits: Sequence[int | bool], name: str = "") -> "Figure":
        """Create a Figure from a sequence of truthy values.

        Accepts either booleans or integers (1 for odd, 0 for even)
        and normalises them to booleans.
        """
        if len(bits) != 4:
            raise ValueError("Bits must be a sequence of length 4")
        normalized = tuple(bool(b) for b in bits)
        return Figure(name=name, bits=normalized)

    def __repr__(self) -> str:
        lines = ''.join('•' if b else '••' for b in self.bits)
        return f"Figure(name='{self.name}', bits={self.bits}, pattern='{lines}')"


# Standard names for the sixteen geomantic figures in one common ordering.
FIGURE_NAMES: List[str] = [
    "Via", "Populus", "Fortuna Major", "Fortuna Minor",
    "Conjunctio", "Carcer", "Tristitia", "Laetitia",
    "Albus", "Rubeus", "Puella", "Puer",
    "Caput Draconis", "Cauda Draconis", "Acquisitio", "Amissio",
]


def random_figure(name: str = "") -> Figure:
    """Generate a random geomantic figure.

    Each of the four bits is chosen independently with equal probability.
    The name field is optional; if provided it is attached to the
    returned figure.
    """
    bits = tuple(bool(random.getrandbits(1)) for _ in range(4))
    return Figure(name=name, bits=bits)


def random_mothers() -> List[Figure]:
    """Generate a list of four random mother figures."""
    return [random_figure() for _ in range(4)]


@dataclass
class Chart:
    """A complete geomantic shield chart.

    The chart stores the sixteen figures generated from the four
    mothers.  The figures are stored in the order they are
    traditionally drawn: mothers (indices 0–3), daughters (4–7),
    nieces (8–11), witnesses (12–13), judge (14).  Some systems
    include a sixteenth figure (reconciler or superjudge); this
    implementation does not compute it by default, but the position is
    reserved for future use.

    Accessors are provided for the mothers, daughters, nieces,
    witnesses and judge.  A house mapping is also provided for the
    12 houses; the first 12 figures (mothers and daughters and two of
    the nieces) are assigned to the houses in the canonical order.
    """

    figures: List[Figure]

    def __post_init__(self) -> None:
        if len(self.figures) < 15:
            raise ValueError(
                "A chart must have at least 15 figures (mothers, daughters, nieces, two witnesses and judge)"
            )

    @classmethod
    def from_mothers(cls, mothers: Sequence[Figure]) -> "Chart":
        """Construct a shield chart from four mother figures.

        The daughters, nieces, witnesses and judge are derived via
        parity combination rules.

        Parameters
        ----------
        mothers : Sequence[Figure]
            The four mother figures.

        Returns
        -------
        Chart
            A complete shield chart with 15 figures (the 16th slot
            reserved for future expansion).
        """
        if len(mothers) != 4:
            raise ValueError("Four mother figures are required")
        m = list(mothers)
        # Derive daughters by reading across the mothers
        daughters = []
        for line in range(4):
            bits = tuple(m[k].bits[line] for k in range(4))
            daughters.append(Figure(name="", bits=bits))
        # Derive nieces
        # niece1 = M1 XOR M2, niece2 = M3 XOR M4
        niece1 = m[0].combine(m[1])
        niece2 = m[2].combine(m[3])
        # niece3 = Daughter1 XOR Daughter2, niece4 = Daughter3 XOR Daughter4
        niece3 = daughters[0].combine(daughters[1])
        niece4 = daughters[2].combine(daughters[3])
        nieces = [niece1, niece2, niece3, niece4]
        # Witnesses
        witness1 = niece1.combine(niece2)
        witness2 = niece3.combine(niece4)
        witnesses = [witness1, witness2]
        # Judge
        judge = witness1.combine(witness2)
        # Reserve slot for superjudge or reconciler (None for now)
        superjudge: Figure | None = None
        figures = m + daughters + nieces + witnesses + [judge]
        # Add placeholder for the 16th figure (superjudge) to make length 16
        figures.append(superjudge)
        return cls(figures=figures)

    @property
    def mothers(self) -> List[Figure]:
        return self.figures[0:4]

    @property
    def daughters(self) -> List[Figure]:
        return self.figures[4:8]

    @property
    def nieces(self) -> List[Figure]:
        return self.figures[8:12]

    @property
    def witnesses(self) -> Tuple[Figure, Figure]:
        return self.figures[12], self.figures[13]

    @property
    def judge(self) -> Figure:
        return self.figures[14]

    @property
    def superjudge(self) -> Figure | None:
        return self.figures[15]

    @property
    def houses(self) -> Dict[int, Figure]:
        """Return a mapping of house number to figure.

        The first 12 figures (four mothers + four daughters + first
        four nieces) fill the 12 houses in order.  House numbering is
        1‑based.  Note: in some traditions nieces are placed in houses
        9–12; this method follows the standard shield chart ordering.
        """
        # houses 1–12 are mothers (0–3), daughters (4–7), nieces (8–11)
        return {i + 1: self.figures[i] for i in range(12)}

    def __repr__(self) -> str:
        names = [fig.name or repr(fig.bits) for fig in self.figures[:15]]
        return f"Chart(mothers={names[:4]}, daughters={names[4:8]}, nieces={names[8:12]}, witnesses={names[12:14]}, judge={names[14]})"